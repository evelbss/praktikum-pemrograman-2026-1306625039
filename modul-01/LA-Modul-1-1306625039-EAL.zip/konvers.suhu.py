# Program Konversi Suhu Celcius - Reamur - Fahrenheit

# Header dan Input Identitas
print("Program Konversi Suhu")
print("Nama : Eva Anggraeni Lubis")
print("NIM  : 1306625039")
print("Kelas: Fisika C")
print()

# Input Parameter Suhu
suhu_awal = float(input("Suhu_awal = "))
suhu_akhir = float(input("Suhu_akhir = "))
selang = float(input("Selang = "))
print()

# Header Tabel
print("==============================================")
print("TABEL KONVERSI")
print("==============================================")
print(f'| {"No.":<4} | {"Celcius":<10} | {"Reamur":<10} | {"Fahrenheit":<10} |')
print("-" * 47)

# Inisialisasi Variabel Perulangan
c = suhu_awal
no = 1

# Perulangan While untuk Perhitungan dan Cetak Tabel
while c <= suhu_akhir:
    r = 0.8 * c
    f = (1.8 * c) + 32

    # Cetak baris tabel
    print(f"| {no:<4} | {c:<10.0f} | {r:<10.0f} | {f:<10.0f} |")

    c += selang
    no += 1

# Penutup Program
print("==============================================")
print("Program selesai.")